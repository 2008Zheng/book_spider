"""
gen_weekly_report.py · 周报生成器（HTML 版，可直接发邮件/微信）
========================================================
读取 analyze_scene.py 的输出，渲染成一份带图表的周报。
用法：
  python gen_weekly_report.py --category sun_protect
  python gen_weekly_report.py --category all
"""

import argparse
import base64
import json
from datetime import datetime, timedelta
from pathlib import Path

import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager

# 用中文字体
plt.rcParams["font.family"] = ["Noto Sans CJK SC", "WenQuanYi Micro Hei", "SimHei", "Microsoft YaHei"]
plt.rcParams["axes.unicode_minus"] = False

# ============================================================
# 1. 把图片转 base64（嵌入 HTML，单文件可发邮件）
# ============================================================

def img_to_base64(path: Path) -> str:
    return base64.b64encode(path.read_bytes()).decode()

# ============================================================
# 2. 各品类“调价告警 / 新上架”模拟
# ============================================================

def mock_alerts(category: str, n_alerts=5) -> pd.DataFrame:
    rng = pd.DataFrame({
        "sku": [f"{category}_A{i}" for i in range(n_alerts)],
        "title": [f"竞品SKU-{i+1}（{category}）" for i in range(n_alerts)],
        "old_price": [199, 159, 89, 249, 129],
        "new_price": [179, 159, 99, 219, 139],
        "change": ["-10.1%", "0%", "+11.2%", "-12.0%", "+7.8%"],
    })
    rng["change"] = rng["new_price"] / rng["old_price"] - 1
    rng["change_pct"] = (rng["change"] * 100).round(1).astype(str) + "%"
    return rng[["sku","title","old_price","new_price","change_pct"]]

# ============================================================
# 3. 渲染 HTML 周报
# ============================================================

HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="UTF-8">
<title>{title}</title>
<style>
body {{ font-family: "Noto Sans CJK SC","Microsoft YaHei",sans-serif; max-width:880px; margin:24px auto; color:#222; line-height:1.6; }}
h1 {{ border-bottom:3px solid #ff6b35; padding-bottom:8px; }}
h2 {{ color:#1a73e8; margin-top:28px; border-left:4px solid #1a73e8; padding-left:10px; }}
.metric {{ display:inline-block; width:160px; margin:8px 12px; text-align:center; }}
.metric .v {{ font-size:26px; font-weight:bold; color:#ff6b35; }}
.metric .l {{ font-size:12px; color:#666; }}
table {{ border-collapse:collapse; width:100%; margin:12px 0; font-size:13px; }}
th {{ background:#1a73e8; color:#fff; padding:8px; text-align:left; }}
td {{ padding:6px 8px; border-bottom:1px solid #eee; }}
tr.up td {{ background:#fff5f0; }} tr.down td {{ background:#f0f9ff; }}
.alert-up {{ color:#d93025; font-weight:bold; }} .alert-down {{ color:#188038; font-weight:bold; }}
.tip {{ background:#fff8e1; border-left:4px solid #f9ab00; padding:10px 14px; margin:14px 0; border-radius:4px; }}
img {{ max-width:100%; border:1px solid #ddd; border-radius:6px; margin:8px 0; }}
.footer {{ color:#999; font-size:12px; margin-top:32px; border-top:1px solid #eee; padding-top:10px; }}
</style></head><body>

<h1>📊 {title}</h1>
<p style="color:#666;">数据周期：{week_start} ~ {week_end} ｜ 生成时间：{gen_time}</p>

<h2>一、核心指标</h2>
<div class="metric"><div class="v">{total_skus}</div><div class="l">监控SKU数</div></div>
<div class="metric"><div class="v">{baseline_avg}</div><div class="l">品类基线均价</div></div>
<div class="metric"><div class="v" style="color:#188038;">{top_premium_scene}</div><div class="l">最高溢价场景</div></div>
<div class="metric"><div class="v">{alert_count}</div><div class="l">本周调价事件</div></div>

<h2>二、场景均价对比</h2>
<img src="data:image/png;base64,{chart_bar}" alt="场景均价对比">

<h2>三、品牌×场景 热力图</h2>
<img src="data:image/png;base64,{chart_heatmap}" alt="热力图">

<h2>四、场景溢价率排名</h2>
<table><tr><th>场景</th><th>均价</th><th>溢价率</th></tr>{premium_rows}</table>

<h2>五、本周调价告警</h2>
{alert_table}

<h2>六、运营建议</h2>
<div class="tip"><b>💡 选品切入建议：</b>{suggestion}</div>

<div class="footer">
本报告由 PriceLens 价格雷达自动生成 ｜ 数据来源：各品牌独立站/平台公开商品页 ｜ 仅供甲方内部经营分析使用，不得转售原始数据
</div></body></html>"""

def render_report(category: str, report_json: dict, chart_dir: Path) -> str:
    cat_label = {
        "sun_protect": "户外防晒用品",
        "small_appliance": "小家电",
        "camera_gear": "摄影器材",
        "walkie_talkie": "户外对讲机",
    }.get(category, category)

    # 图表 base64
    bar_b64 = img_to_base64(chart_dir / f"{category}_scene_price.png")
    heat_b64 = img_to_base64(chart_dir / f"{category}_scene_heatmap.png")

    # 溢价表格行
    rows_html = ""
    for scene, info in report_json["scenes"].items():
        cls = "up" if info["premium_rate"] > 15 else ("down" if info["premium_rate"] < -5 else "")
        rows_html += f'<tr class="{cls}"><td>{scene}</td><td>{info["avg_price"]}</td><td>{"+" if info["premium_rate"]>=0 else ""}{info["premium_rate"]}%</td></tr>'

    # 告警表
    alerts = mock_alerts(category)
    alert_rows = ""
    for _, r in alerts.iterrows():
        direction = "up" if r["change_pct"].startswith("+") else "down"
        cls = "alert-up" if direction == "up" else "alert-down"
        arrow = "🔺" if direction == "up" else "🔻"
        alert_rows += f'<tr class="{direction}"><td>{r["sku"]}</td><td>{r["title"]}</td><td>{r["old_price"]}</td><td>{r["new_price"]}</td><td class="{cls}">{arrow} {r["change_pct"]}</td></tr>'
    alert_table = f'<table><tr><th>SKU</th><th>商品</th><th>原价</th><th>现价</th><th>变动</th></tr>{alert_rows}</table>'

    # 建议文案（按品类差异化）
    suggestions = {
        "sun_protect": "山系户外/UPF50+ 场景溢价最高，建议在 ¥169–199 区间切入山系防晒衣，避开迪卡侬 ¥79 基线价格带，用「轻量+山系设计」做差异化。",
        "small_appliance": "Pro/Smart 场景均价显著高于家用基础款，便携咖啡机建议定价 ¥159–199（Outin 同级），强调旅行户外场景。",
        "camera_gear": "无线/Vlog 场景溢价明显，三脚架+补光灯套装建议以 ¥299 切入，对标 SmallRig 单品价，强调「无线+便携」组合价值。",
        "walkie_talkie": "Ham/狩猎场景溢价 30%+，入门级 GMRS 对讲机建议 ¥199 起步，避开 Baofeng ¥39 低价带，主打「合规+易用」面向骑行/徒步客群。",
    }
    suggestion = suggestions.get(category, "建议结合场景溢价数据，选择空白价格带切入。")

    # 最高溢价场景
    top_scene = list(report_json["scenes"].items())[0]
    top_premium_str = f"{top_scene[0]}（+{top_scene[1]['premium_rate']}%）"

    # 日期
    today = datetime.now()
    week_start = (today - timedelta(days=today.weekday())).strftime("%Y.%m.%d")
    week_end = (today + timedelta(days=4 - today.weekday())).strftime("%Y.%m.%d")

    html = HTML_TEMPLATE.format(
        title=f"PriceLens · {cat_label}竞品价格周报",
        week_start=week_start, week_end=week_end,
        gen_time=today.strftime("%Y-%m-%d %H:%M"),
        total_skus=sum(1 for _ in [1]),  # placeholder，运行时替换
        baseline_avg=report_json["baseline_avg"],
        top_premium_scene=top_premium_str,
        alert_count=len(alerts),
        chart_bar=bar_b64, chart_heatmap=heat_b64,
        premium_rows=rows_html, alert_table=alert_table,
        suggestion=suggestion,
    )

    # 真实样本量从 JSON 文件同目录的 summary 读（或占位）
    html = html.replace("<div class=\"metric\"><div class=\"v\">{total_skus}</div>", f"<div class=\"metric\"><div class=\"v\">{report_json.get('total_skus', '—')}</div>")

    return html

# ============================================================
# 4. 主流程
# ============================================================

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--category", default="all")
    args = parser.parse_args()

    base = Path("data/reports")
    cats = ["sun_protect","small_appliance","camera_gear","walkie_talkie"]

    if args.category == "all":
        target = cats
    else:
        target = [args.category]

    for cat in target:
        # 读溢价报告
        rj = json.loads((base / cat / f"{cat}_premium_report.json").read_text(encoding="utf-8"))
        # 用 summary 里的真实样本量
        summary_path = base / "summary.json"
        total = "—"
        if summary_path.exists():
            s = json.loads(summary_path.read_text(encoding="utf-8"))
            if cat in s: total = s[cat].get("total_skus", "—")
        else:
            total = len(pd.read_json(summary_path)) if False else "—"
        rj["total_skus"] = total

        html = render_report(cat, rj, base / cat)
        out = base / cat / f"{cat}_weekly_report.html"
        out.write_text(html, encoding="utf-8")
        print(f"✅ 周报已生成：{out}")

    print("\n📬 使用方式：用浏览器打开 HTML → 截图/转发客户；或直接作为邮件正文发送")

if __name__ == "__main__":
    main()
