"""
run_demo.py · 一键演示
===================
1) 生成 4 品类模拟数据
2) 跑场景溢价分析（出图 + JSON 报告）
3) 生成 4 份 HTML 周报

真实环境只需把 mock_xxx() 替换为：parser 输出 + SQLite 读取
"""

import subprocess
import sys
from pathlib import Path

def main():
    print("=" * 60)
    print("  PriceLens · 4 品类场景溢价分析 · 一键演示")
    print("=" * 60)

    # Step 1: 分析
    print("\n▶ Step 1/2: 场景溢价分析")
    subprocess.run([sys.executable, "analyze_scene.py", "--category", "all"], check=True)

    # Step 2: 周报
    print("\n▶ Step 2/2: 生成周报")
    subprocess.run([sys.executable, "gen_weekly_report.py", "--category", "all"], check=True)

    print("\n" + "=" * 60)
    print("  ✅ 全部完成！查看以下文件：")
    print("=" * 60)
    base = Path("data/reports")
    for cat in ["sun_protect","small_appliance","camera_gear","walkie_talkie"]:
        d = base / cat
        if d.exists():
            for f in sorted(d.iterdir()):
                print(f"  📄 {f}")

if __name__ == "__main__":
    main()
